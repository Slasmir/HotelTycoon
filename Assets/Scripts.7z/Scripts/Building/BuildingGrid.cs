﻿using UnityEngine;

public class BuildingGrid {

    private bool[,] Grid;

    float Scale;

    int width { get { return Grid.GetLength(0); } }
    int length { get { return Grid.GetLength(1); } }

    public BuildingGrid(int _width, int _length, float _Scale)
    {
        Grid = new bool[_width, _length];
        Scale = _Scale;
        PopulateGrid(true);
    }

    private void PopulateGrid(bool PopulationValue)
    {
        for (int w = 0; w < Grid.GetLength(0); w++)
            for (int l = 0; l < Grid.GetLength(1); l++)
                Grid[w,l] = PopulationValue;
    }

    public bool CheckGrid(Vector2 location) {
        return Grid[Mathf.RoundToInt(location.x), Mathf.RoundToInt(location.y)];
    }

    public bool CheckGrid(Vector2 location, Vector2 Size)
    {
        if (!CheckBounds(location) || !CheckBounds(location + Size))
            return false;

        if (Size.x == 0 || Size.y == 0)
            return false;

        Vector2 AbsSize = new Vector2(Mathf.Abs(Size.x), Mathf.Abs(Size.y));
        Vector2 Direction = new Vector2(Size.x / AbsSize.x, Size.y / AbsSize.y);

        for (int w = 0; w < Mathf.RoundToInt(AbsSize.x); w++)
        {
            int x = w * Mathf.RoundToInt(Direction.x);
            if (Direction.x < 0) x--;
            for (int l = 0; l < Mathf.RoundToInt(AbsSize.y); l++)
            {
                int y = l * Mathf.RoundToInt(Direction.y);
                if (Direction.y < 0) y--;
                Vector2 CheckPoint = location + new Vector2(x, y);
                if (Grid[Mathf.RoundToInt(CheckPoint.x), Mathf.RoundToInt(CheckPoint.y)] == false)
                    return false;
            }
        }

        return true;
    }

    public bool UpdateGrid(Vector2 location)
    {
        return UpdateGrid(location, Vector2.one);
    }

    public bool UpdateGrid(Vector2 location, Vector2 Size)
    {
        if (!CheckGrid(location, Size)) return false;

        Debug.Log(Size);

        Vector2 AbsSize = new Vector2(Mathf.Abs(Size.x), Mathf.Abs(Size.y));
        Vector2 Direction = new Vector2(Size.x / AbsSize.x, Size.y / AbsSize.y);

        for (int w = 0; w < Mathf.RoundToInt(AbsSize.x); w++)
        {
            int x = w * Mathf.RoundToInt(Direction.x);
            if (Direction.x < 0) x--;

            for (int l = 0; l < Mathf.RoundToInt(AbsSize.y); l++)
            {
                int y = l * Mathf.RoundToInt(Direction.y);
                if (Direction.y < 0) y--;
                Vector2 CheckPoint = location + new Vector2(x, y);
                Grid[Mathf.RoundToInt(CheckPoint.x), Mathf.RoundToInt(CheckPoint.y)] = false;
            }
        }

        return true;
    }

    bool CheckBounds(Vector2 location)
    {
        if (location.x > Grid.GetLength(0)) return false;
        if (location.y > Grid.GetLength(1)) return false;
        if (location.x < 0) return false;
        if (location.y < 0) return false;

        return true;
    }

    public void DebugGizmoDisplay(Vector3 origin)
    {
        for (int w = 0; w < Grid.GetLength(0); w++)
        {
            for (int l = 0; l < Grid.GetLength(1); l++)
            {
                Gizmos.color = Grid[w, l] ? Color.green : Color.red ;
                Gizmos.DrawCube(origin + new Vector3(w * Scale, -.2f, l * Scale) + new Vector3(.5f * Scale,0, .5f * Scale), new Vector3(Scale, 0.4f, Scale) * 0.9f);
            }
        }
    }
}
