﻿using UnityEngine;

public class BuildingItemController : MonoBehaviour{

    GameObject OriginalItemToPlace;
    GameObject ItemToPlace;
    public Vector2 GetItemSize { get { return CalculateBounds(ItemToPlace) * 1/Scale; } }

    float SavedRotation = 0;

    public bool IsPlacingObject { get { return ItemToPlace != null; } }
    float Scale;
    public LayerMask Mask;
    BuildingGrid grid;

    void Start()
    {
        Mask = ~(1 << LayerMask.NameToLayer("PlacingObject"));
    }

	public void SetNewBuildItem(GameObject _ItemToPlace, float _Scale, BuildingGrid _Grid)
    {
        OriginalItemToPlace = _ItemToPlace;
        ItemToPlace = Instantiate(_ItemToPlace);
        SetLayerOnChildren(ItemToPlace, LayerMask.NameToLayer("PlacingObject"));
        Scale = _Scale;
        grid = _Grid;
        SavedRotation = 0;
    }

    void SetLayerOnChildren(GameObject SetObject, LayerMask Layer)
    {
        ItemToPlace.layer = Layer;
        foreach(Transform t in SetObject.GetComponentsInChildren<Transform>(true))
        {
            t.gameObject.layer = Layer;
        }
    }

    void Update()
    {
        if (ItemToPlace != null)
        {
            ItemToPlace.transform.position = MouseUtility.MouseRaycastPositionRounded(Scale, Mask);
            VisualUpdate();
        }
    }

    void VisualUpdate()
    {
        Color MatColor = grid.CheckGrid(GetLocation(), GetItemSize) ? Color.green : Color.red;
        ItemToPlace.GetComponentInChildren<Renderer>().material.color = MatColor;
    }

    public void RotateObject(bool ClockWise)
    {
        if (ItemToPlace == null)
            return;

        float Rotation = ClockWise ? 90f : -90f;
        SavedRotation += Rotation;
        ItemToPlace.transform.Rotate(Vector3.up, Rotation);
    }

    Vector2 CalculateBounds(GameObject CalculationObject)
    {
        Renderer[] children = CalculationObject.GetComponentsInChildren<Renderer>();
        Bounds bounds = new Bounds(CalculationObject.transform.position, Vector3.zero);
        foreach (Renderer r in children)
            bounds.Encapsulate(r.bounds);


        //Rotate the bounds
        Vector2 Size = new Vector2(bounds.size.x, bounds.size.z);

        Vector2 Dir = RotateVector2(new Vector2(1,1), -SavedRotation);

        return Vector2.Scale(Size, Dir);
    }

    Vector2 RotateVector2(Vector2 aPoint, float aDegree)
    {
        float sin = Mathf.Sin(aDegree * Mathf.Deg2Rad);
        float cos = Mathf.Cos(aDegree * Mathf.Deg2Rad);

        float tx = aPoint.x;
        float ty = aPoint.y;
        aPoint.x = (cos * tx) - (sin * ty);
        aPoint.y = (sin * tx) + (cos * ty);
        return aPoint;
    }

    public Vector2 GetLocation()
    {
        Vector3 MousePos = MouseUtility.MouseRaycastPositionRounded(Scale, Mask);
        return new Vector2(MousePos.x / Scale, MousePos.z / Scale);
    }

    public GameObject PlaceObject()
    {
        GameObject ReturningItem = Instantiate(OriginalItemToPlace);

        ReturningItem.transform.position = ItemToPlace.transform.position;
        ReturningItem.transform.rotation = ItemToPlace.transform.rotation;

        Destroy(ItemToPlace);
        ItemToPlace = null;
        OriginalItemToPlace = null;
        return ReturningItem;
    }

    public void Cleanup()
    {
        Destroy(ItemToPlace);
        ItemToPlace = null;
    }

    
}
